package com.example.endsem2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "StudentDB";
    public static final int DB_VERSION = 3;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE student (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, gender TEXT, hobbies TEXT, branch TEXT, age INTEGER, dob TEXT, skill INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS student");
        onCreate(db);
    }

    public boolean insertStudent(String name, String gender, String hobbies, String branch, int age, String dob, int skill) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("gender", gender);
        cv.put("hobbies", hobbies);
        cv.put("branch", branch);
        cv.put("age", age);
        cv.put("dob", dob);
        cv.put("skill", skill);
        long result = db.insert("student", null, cv);
        return result != -1;
    }

    public void deleteStudent(int studentId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("student", "id = ?", new String[]{String.valueOf(studentId)});
    }

    public void updateStudent(int studentId, String newName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", newName);
        db.update("student", cv, "id = ?", new String[]{String.valueOf(studentId)});
    }

    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM student", null);
    }
}