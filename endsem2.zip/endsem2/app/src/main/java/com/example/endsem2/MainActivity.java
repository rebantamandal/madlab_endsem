package com.example.endsem2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText etName, etAge;
    RadioButton rbMale, rbFemale, rbothers;
    CheckBox cbDance, cbMusic, cbGaming;
    Spinner spBranch;
    Button btnSave, btnView, btnPickDate;
    SeekBar seekSkill;
    TextView tvSkillValue, tvDate;
    DBHelper dbHelper;
    String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        rbothers = findViewById(R.id.rbothers);
        cbDance = findViewById(R.id.cbDance);
        cbGaming = findViewById(R.id.cbGaming);
        cbMusic = findViewById(R.id.cbMusic);
        spBranch = findViewById(R.id.spBranch);
        btnSave = findViewById(R.id.btnSave);
        btnView = findViewById(R.id.btnView);
        btnPickDate = findViewById(R.id.btnPickDate);
        tvDate = findViewById(R.id.tvDate);
        seekSkill = findViewById(R.id.seekSkill);
        tvSkillValue = findViewById(R.id.tvSkillValue);

        dbHelper = new DBHelper(this);

        seekSkill.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvSkillValue.setText("Selected: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnPickDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                    (view, year1, month1, dayOfMonth) -> {
                        selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                        tvDate.setText("Selected: " + selectedDate);
                    }, year, month, day);
            datePickerDialog.show();
        });

        btnSave.setOnClickListener(view -> {
            String name = etName.getText().toString().trim();
            String ageStr = etAge.getText().toString().trim();
            if (name.isEmpty() || ageStr.isEmpty()) {
                Toast.makeText(MainActivity.this, "Data not entered", Toast.LENGTH_SHORT).show();
                return;
            }

            int age = Integer.parseInt(ageStr);
            String gender = rbMale.isChecked() ? "Male" : rbFemale.isChecked() ? "Female" : rbothers.isChecked() ? "Others" : "Not Specified";
            StringBuilder hobbies = new StringBuilder();
            if (cbDance.isChecked()) hobbies.append("Dance ");
            if (cbMusic.isChecked()) hobbies.append("Music ");
            if (cbGaming.isChecked()) hobbies.append("Gaming");
            String branch = spBranch.getSelectedItem().toString();
            int skill = seekSkill.getProgress();

            boolean inserted = dbHelper.insertStudent(name, gender, hobbies.toString().trim(), branch, age, selectedDate, skill);
            if (inserted)
                Toast.makeText(MainActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(MainActivity.this, "Error saving data", Toast.LENGTH_SHORT).show();
        });

        btnView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ViewActivity.class));
        });
    }
}