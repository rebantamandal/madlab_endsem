package com.example.endsem2;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {

    GridView gridView;
    ArrayAdapter<String> adapter;
    ArrayList<String> studentList = new ArrayList<>();
    DBHelper dbHelper;
    int selectedItemIndex = -1;
    ArrayList<Integer> studentIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        gridView = findViewById(R.id.gridView);
        dbHelper = new DBHelper(this);

        loadStudents();

        registerForContextMenu(gridView);

        gridView.setOnItemLongClickListener((adapterView, view, i, l) -> {
            selectedItemIndex = i;
            return false;
        });
    }

    void loadStudents() {
        studentList.clear();
        studentIds.clear();
        Cursor cursor = dbHelper.getAllStudents();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            studentIds.add(id);
            String student = "ID: " + id +
                    "\nName: " + cursor.getString(1) +
                    "\nGender: " + cursor.getString(2) +
                    "\nHobbies: " + cursor.getString(3) +
                    "\nBranch: " + cursor.getString(4) +
                    "\nAge: " + cursor.getInt(5) +
                    "\nDOB: " + cursor.getString(6) +
                    "\nSkill: " + cursor.getInt(7);
            studentList.add(student);
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, studentList);
        gridView.setAdapter(adapter);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (selectedItemIndex == -1) return false;

        int studentId = studentIds.get(selectedItemIndex);

        if (item.getItemId() == R.id.menu_view) {
            Toast.makeText(this, studentList.get(selectedItemIndex), Toast.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.menu_edit) {
            showEditDialog(studentId);
            return true;
        } else if (item.getItemId() == R.id.menu_delete) {
            showDeleteConfirmation(studentId);
            return true;
        }

        return super.onContextItemSelected(item);
    }

    void showEditDialog(int studentId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Student Name");

        final EditText input = new EditText(this);
        input.setHint("Enter new name");
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newName = input.getText().toString().trim();
            if (!newName.isEmpty()) {
                dbHelper.updateStudent(studentId, newName);
                Toast.makeText(ViewActivity.this, "Name updated", Toast.LENGTH_SHORT).show();
                loadStudents();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    void showDeleteConfirmation(int studentId) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this student?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    dbHelper.deleteStudent(studentId);
                    Toast.makeText(ViewActivity.this, "Student deleted", Toast.LENGTH_SHORT).show();
                    loadStudents();
                })
                .setNegativeButton("No", null)
                .show();
    }
}